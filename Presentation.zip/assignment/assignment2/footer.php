<footer>
    <p>&copy; 2024 KRITIKA | Student ID: 202105025</p>
</footer>
